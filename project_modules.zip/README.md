# Framework Multimodal A1 com Agentes Evolutivos

Este repositório contém uma aplicação Streamlit que implementa um framework completo para classificação multimodal com análise científica automatizada, estatísticas, agentes evolutivos e especialização por domínio. O objetivo é fornecer uma estrutura reprodutível e extensível para experimentos de classificação segundo critérios Qualis A1.

## Funcionalidades principais

- **Classificação multimodal**: suporta imagens, textos, PDFs e outros formatos. Utiliza modelos Gemini (`gemini-1.5-flash` e `gemini-1.5-pro`) para efetuar a classificação, com opção de execução paralela via Ray.
- **Agentes inteligentes**: gera relatórios científicos, revisões críticas, protocolos de replicação, análises estatísticas e sintetiza uma versão evolutiva combinando todos os relatórios. Inclui também agentes especialistas para domínios de medicina, indústria e educação.
- **Estatísticas e métricas**: calcula acurácia, F1 macro, matriz de confusão e outras métricas apropriadas para tarefas binárias e multiclasse.
- **Gerador de artigo**: monta automaticamente um artigo científico em estilo IMRaD a partir dos relatórios e permite exportação em JSON, LaTeX e PDF (requer `pdflatex`).
- **Persistência**: registra execuções, métricas e textos no banco de dados PostgreSQL usando SQLAlchemy.
- **Dashboard**: apresenta visualizações interativas com Plotly para distribuição de classes e matrizes de confusão.
- **Docker**: inclui `Dockerfile` e `docker-compose.yml` para facilitar o deploy e a configuração.

## Estrutura de pastas

```
project/
├── app.py
├── pages/
│   ├── 1_classificacao.py
│   ├── 2_agentes.py
│   ├── 3_estatistica.py
│   ├── 4_artigo_cientifico.py
│   ├── 5_dashboard.py
├── agents/
│   ├── classifier.py
│   ├── analyst.py
│   ├── specialists.py
├── utils/
│   ├── hashing.py
│   ├── metrics.py
│   ├── exporter.py
│   ├── article_builder.py
│   ├── latex_exporter.py
│   ├── parallel.py
│   ├── db.py
├── results/
├── requirements.txt
├── Dockerfile
├── docker-compose.yml
└── README.md
```

## Uso

Instale as dependências (requer Python 3.10 ou superior):

```bash
pip install -r requirements.txt
```

Execute a aplicação localmente com:

```bash
streamlit run app.py
```

Para rodar em Docker:

```bash
docker-compose up --build
```

Defina as variáveis de ambiente `GEMINI_API_KEY` para a chave do Google Gemini e `FRAMEWORK_DB_URL` para a URL do banco de dados PostgreSQL.

## Considerações

Esta aplicação foi desenvolvida com foco em reprodutibilidade científica e extensibilidade. Está estruturada em módulos independentes para facilitar sua manutenção e evolução.